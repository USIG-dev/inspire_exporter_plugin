
from qgis.PyQt.QtWidgets import QAction, QFileDialog
from qgis.core import QgsProject, QgsVectorLayer
from qgis.PyQt.QtXml import QDomDocument
import os
from datetime import date

class InspireExporter:

    def __init__(self, iface):
        self.iface = iface

    def initGui(self):
        self.action = QAction("Exportar QMD + INSPIRE", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.iface.addPluginToMenu("&INSPIRE Exporter", self.action)

    def unload(self):
        self.iface.removePluginMenu("&INSPIRE Exporter", self.action)

    def run(self):

        base_folder = QFileDialog.getExistingDirectory(
            None,
            "Escolher pasta exportação INSPIRE"
        )

        if not base_folder:
            return

        qmd_folder = os.path.join(base_folder, "QMD")
        inspire_folder = os.path.join(base_folder, "INSPIRE_FROM_QMD")

        os.makedirs(qmd_folder, exist_ok=True)
        os.makedirs(inspire_folder, exist_ok=True)

        project = QgsProject.instance()
        today = date.today().isoformat()

        for layer in project.mapLayers().values():

            if not isinstance(layer, QgsVectorLayer):
                continue

            md = layer.metadata()
            name = layer.name().replace(" ", "_")

            # QMD
            qmd_doc = QDomDocument("qgis")
            root = qmd_doc.createElement("qgis")
            qmd_doc.appendChild(root)
            md.writeMetadataXml(root, qmd_doc)

            with open(os.path.join(qmd_folder, f"{name}.qmd"), "w", encoding="utf-8") as f:
                f.write(qmd_doc.toString())

            # INSPIRE minimal
            title = md.title() or layer.name()
            abstract = md.abstract() or "Sem descrição"

            extent = layer.extent()
            minx, miny, maxx, maxy = extent.xMinimum(), extent.yMinimum(), extent.xMaximum(), extent.yMaximum()

            xml = f'''<?xml version="1.0" encoding="UTF-8"?>
<gmd:MD_Metadata xmlns:gmd="http://www.isotc211.org/2005/gmd"
 xmlns:gco="http://www.isotc211.org/2005/gco">

  <gmd:fileIdentifier>
    <gco:CharacterString>{layer.id()}</gco:CharacterString>
  </gmd:fileIdentifier>

  <gmd:dateStamp>
    <gco:Date>{today}</gco:Date>
  </gmd:dateStamp>

  <gmd:identificationInfo>
    <gmd:MD_DataIdentification>

      <gmd:citation>
        <gmd:CI_Citation>
          <gmd:title>
            <gco:CharacterString>{title}</gco:CharacterString>
          </gmd:title>
        </gmd:CI_Citation>
      </gmd:citation>

      <gmd:abstract>
        <gco:CharacterString>{abstract}</gco:CharacterString>
      </gmd:abstract>

      <gmd:extent>
        <gmd:EX_Extent>
          <gmd:geographicElement>
            <gmd:EX_GeographicBoundingBox>
              <gmd:westBoundLongitude><gco:Decimal>{minx}</gco:Decimal></gmd:westBoundLongitude>
              <gmd:eastBoundLongitude><gco:Decimal>{maxx}</gco:Decimal></gmd:eastBoundLongitude>
              <gmd:southBoundLatitude><gco:Decimal>{miny}</gco:Decimal></gmd:southBoundLatitude>
              <gmd:northBoundLatitude><gco:Decimal>{maxy}</gco:Decimal></gmd:northBoundLatitude>
            </gmd:EX_GeographicBoundingBox>
          </gmd:geographicElement>
        </gmd:EX_Extent>
      </gmd:extent>

    </gmd:MD_DataIdentification>
  </gmd:identificationInfo>

</gmd:MD_Metadata>
'''

            with open(os.path.join(inspire_folder, f"{name}_INSPIRE.xml"), "w", encoding="utf-8") as f:
                f.write(xml)

        self.iface.messageBar().pushMessage(
            "INSPIRE Exporter",
            "Exportação concluída",
            level=0
        )
